run the codes using python 3
nltk should be installed for porter stemming
choice of function must be given as input in parta (0 for sigmoid 1 for tanh)